package ws.wzstudios.wzmenus;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class MenuHolder implements InventoryHolder {
    private final MenuDefinition menu;
    private Inventory inventory;
    private final int page;
    public MenuHolder(MenuDefinition menu, int page) { this.menu = menu; this.page = page; }
    public int page() { return page; }
    public MenuDefinition menu() { return menu; }
    public void inventory(Inventory inventory) { this.inventory = inventory; }
    @Override public Inventory getInventory() { return inventory; }
}
