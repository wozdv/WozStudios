package ws.wzstudios.wzmenus;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Cooldowns persistentes por UUID, ID de menú e ID de objeto. */
public final class ClaimCooldowns {
    private final WzMenusPlugin plugin;
    private final File file;
    private final Map<String, Long> expirations = new HashMap<>();

    public ClaimCooldowns(WzMenusPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "cooldowns.yml");
        load();
    }

    private String key(UUID uuid, String menu, String item) {
        return uuid + "." + menu.toLowerCase(java.util.Locale.ROOT) + "." + item.toLowerCase(java.util.Locale.ROOT);
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        long now = System.currentTimeMillis();
        for (String uuid : cfg.getKeys(false)) {
            var menus = cfg.getConfigurationSection(uuid);
            if (menus == null) continue;
            for (String menu : menus.getKeys(false)) {
                var items = menus.getConfigurationSection(menu);
                if (items == null) continue;
                for (String item : items.getKeys(false)) {
                    long expiry = items.getLong(item, 0L);
                    if (expiry > now) expirations.put(uuid + "." + menu + "." + item, expiry);
                }
            }
        }
    }

    public long remaining(UUID uuid, String menu, String item) {
        long expiry = expirations.getOrDefault(key(uuid, menu, item), 0L);
        return Math.max(0L, (expiry - System.currentTimeMillis() + 999L) / 1000L);
    }

    public void claim(UUID uuid, String menu, String item, long seconds) {
        expirations.put(key(uuid, menu, item), System.currentTimeMillis() + seconds * 1000L);
        save();
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        long now = System.currentTimeMillis();
        expirations.entrySet().removeIf(e -> e.getValue() <= now);
        for (var entry : expirations.entrySet()) cfg.set(entry.getKey(), entry.getValue());
        try { cfg.save(file); }
        catch (IOException ex) { plugin.getLogger().severe("No se pudieron guardar los cooldowns: " + ex.getMessage()); }
    }

    public static String format(long seconds) {
        long days = seconds / 86400, hours = seconds % 86400 / 3600;
        long minutes = seconds % 3600 / 60, secs = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0) sb.append(minutes).append("m ");
        if (secs > 0 || sb.isEmpty()) sb.append(secs).append("s");
        return sb.toString().trim();
    }
}
