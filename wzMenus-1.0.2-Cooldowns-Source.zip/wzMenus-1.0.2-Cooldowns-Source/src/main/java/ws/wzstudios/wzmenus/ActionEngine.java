package ws.wzstudios.wzmenus;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import java.time.Duration;
import java.util.*;

public final class ActionEngine {
    private final WzMenusPlugin plugin;
    public ActionEngine(WzMenusPlugin plugin) { this.plugin = plugin; }

    public void execute(Player player, List<String> actions, String sourceMenu) {
        if (actions.isEmpty()) return;
        run(player, List.copyOf(actions), 0, sourceMenu);
    }
    private void run(Player player, List<String> actions, int index, String sourceMenu) {
        if (!player.isOnline() || index >= actions.size()) return;
        String action = actions.get(index).trim();
        int end = action.indexOf(']');
        if (!action.startsWith("[") || end < 2) { warn(sourceMenu, action); next(player, actions, index, sourceMenu); return; }
        String type = action.substring(1, end).toLowerCase(Locale.ROOT);
        String value = plugin.integrations().placeholders(player, action.substring(end + 1).trim());
        try {
            switch (type) {
                case "message" -> player.sendMessage(plugin.text().parse(value));
                case "actionbar" -> player.sendActionBar(plugin.text().parse(value));
                case "broadcast" -> Bukkit.broadcast(plugin.text().parse(value));
                case "title" -> {
                    String[] parts = value.split(";", 2);
                    player.showTitle(Title.title(plugin.text().parse(parts[0]), plugin.text().parse(parts.length > 1 ? parts[1] : ""),
                        Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))));
                }
                case "sound" -> player.playSound(player.getLocation(), Sound.valueOf(value.toUpperCase(Locale.ROOT)), 1f, 1f);
                case "player" -> { if (!value.isBlank()) player.performCommand(stripSlash(value)); }
                case "console" -> { if (!value.isBlank()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), stripSlash(value)); }
                case "open" -> { if (!value.isBlank()) plugin.openMenu(player, value, true); }
                case "back" -> plugin.back(player);
                case "refresh" -> plugin.openMenu(player, sourceMenu, false);
                case "close" -> player.closeInventory();
                case "delay" -> {
                    long ticks = Long.parseLong(value);
                    if (ticks < 1 || ticks > 72000) throw new IllegalArgumentException("delay fuera de rango (1-72000 ticks)");
                    Bukkit.getScheduler().runTaskLater(plugin, () -> run(player, actions, index + 1, sourceMenu), ticks);
                    return;
                }
                default -> warn(sourceMenu, action);
            }
        } catch (Exception e) { plugin.getLogger().warning("Acción inválida en " + sourceMenu + ": " + action + " (" + e.getMessage() + ")"); }
        next(player, actions, index, sourceMenu);
    }
    private void next(Player p, List<String> actions, int index, String source) { run(p, actions, index + 1, source); }
    private void warn(String menu, String action) { plugin.getLogger().warning("Acción desconocida en " + menu + ": " + action); }
    private String stripSlash(String cmd) { return cmd.startsWith("/") ? cmd.substring(1) : cmd; }
}
