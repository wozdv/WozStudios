package ws.wzstudios.wzmenus;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

/** Admin-only visual editor. All YAML writes and inventory changes run on the server thread. */
public final class MenuEditor implements Listener {
    private static final Pattern SAFE_ID = Pattern.compile("[a-zA-Z0-9_-]{1,48}");
    private final WzMenusPlugin plugin;
    private final Map<UUID, PendingInput> pending = new HashMap<>();
    private record PendingInput(String id, int slot, String field) {}
    public MenuEditor(WzMenusPlugin plugin) {
        this.plugin=plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }
    public void cancelAll() { pending.clear(); }
    public void quit(Player player) { pending.remove(player.getUniqueId()); }
    private File file(String id) { return new File(plugin.getDataFolder(), "menus/"+id+".yml"); }
    private boolean valid(String id) { return SAFE_ID.matcher(id).matches(); }
    private void say(CommandSender sender, String message) { sender.sendMessage(plugin.text().parse("&#BFC4CBWz Studios &8» &7"+message)); }
    public void create(CommandSender sender, String id) {
        id=id.toLowerCase(Locale.ROOT);
        if (!valid(id)) { say(sender,"&cID inválido. Solo letras, números, guion y guion bajo."); return; }
        File f=file(id);
        if (f.exists()) { say(sender,"&cYa existe ese menú."); return; }
        YamlConfiguration yaml=new YamlConfiguration();
        yaml.set("menu.title", "&#BFC4CB&l"+id);
        yaml.set("menu.rows", 6);
        yaml.set("menu.permission", "");
        yaml.set("filler.material", "BLACK_STAINED_GLASS_PANE");
        yaml.set("filler.name", " ");
        try { yaml.save(f); plugin.menus().load(); say(sender,"&aMenú creado: &f"+id); }
        catch(IOException ex) { plugin.getLogger().warning("No se pudo crear "+id+": "+ex.getMessage()); say(sender,"&cNo se pudo guardar el archivo."); }
    }
    public void delete(CommandSender sender, String id) {
        id=id.toLowerCase(Locale.ROOT);
        if (!valid(id) || !file(id).isFile()) { say(sender,"&cMenú no encontrado."); return; }
        if (!file(id).delete()) { say(sender,"&cNo se pudo eliminar el archivo."); return; }
        plugin.menus().load(); say(sender,"&aMenú eliminado: &f"+id);
    }
    public void open(Player player, String id) { show(player,id.toLowerCase(Locale.ROOT),-1); }
    private void show(Player player,String id,int selected) {
        if (!player.hasPermission("wzmenus.edit")) return;
        if (!valid(id) || !file(id).isFile() || plugin.menus().get(id)==null) { say(player,"&cMenú no encontrado o inválido."); return; }
        MenuDefinition definition=plugin.menus().get(id);
        EditorHolder holder=new EditorHolder(id,selected);
        Inventory inv=Bukkit.createInventory(holder,54,plugin.text().parse("&8Editor &7» &f"+id));
        holder.setInventory(inv);
        for (int slot=0;slot<45;slot++) {
            MenuDefinition.MenuEntry entry=definition.items().get(slot);
            if (entry!=null) inv.setItem(slot,icon(entry.material(),"&f"+entry.id(),"&7Clic para editar este objeto"));
            else inv.setItem(slot,icon(Material.GRAY_STAINED_GLASS_PANE,"&8Slot "+slot,"&7Clic para crear un objeto"));
        }
        inv.setItem(45,icon(Material.BOOK,"&fTítulo","&7Cambiar título por chat"));
        inv.setItem(46,icon(Material.CHEST,"&fFilas","&7Alternar entre 1 y 6 filas"));
        inv.setItem(47,icon(Material.EMERALD,"&aPrevisualizar","&7Abrir el menú normal"));
        inv.setItem(48,icon(Material.LIME_DYE,"&aGuardar","&7Los cambios se guardan automáticamente"));
        inv.setItem(49,icon(Material.BARRIER,"&cCerrar","&7Salir del editor"));
        if (selected>=0) {
            inv.setItem(50,icon(Material.NAME_TAG,"&fNombre","&7Escribir nuevo nombre por chat"));
            inv.setItem(51,icon(Material.WRITABLE_BOOK,"&fLore","&7Separar líneas con |"));
            inv.setItem(52,icon(Material.IRON_SWORD,"&fMaterial","&7Tomar material de la mano principal"));
            inv.setItem(53,icon(Material.REDSTONE,"&cEliminar","&7Shift + clic para eliminar"));
        }
        player.openInventory(inv);
    }
    private ItemStack icon(Material material,String title,String lore) {
        ItemStack item=new ItemStack(material);
        ItemMeta meta=item.getItemMeta();
        if (meta!=null) { meta.displayName(plugin.text().parse(title)); meta.lore(List.of(plugin.text().parse(lore))); item.setItemMeta(meta); }
        return item;
    }
    public boolean handleClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof EditorHolder holder)) return false;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || !player.hasPermission("wzmenus.edit")) return true;
        if (event.getClickedInventory()!=event.getView().getTopInventory()) return true;
        int slot=event.getRawSlot(); String id=holder.menuId(); int selected=holder.selectedSlot();
        if (slot<0 || slot>=54) return true;
        if (slot<45) {
            if (slot>=plugin.menus().get(id).rows()*9) { say(player,"&cEl slot está fuera del tamaño del menú."); return true; }
            YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file(id));
            if (!yaml.isConfigurationSection("items.slot_"+slot) && !hasSlot(yaml,slot)) {
                yaml.set("items.slot_"+slot+".slot",slot);
                yaml.set("items.slot_"+slot+".material","STONE");
                yaml.set("items.slot_"+slot+".name","&fNuevo objeto");
                yaml.set("items.slot_"+slot+".lore",List.of("&7Edita este objeto"));
                save(player,id,yaml);
            }
            show(player,id,slot);
        } else if(slot==45) prompt(player,id,-1,"title","Escribe el nuevo título del menú en el chat. 'cancel' para cancelar.");
        else if(slot==46) {
            YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file(id));
            int next=yaml.getInt("menu.rows",6)%6+1;
            if (hasSlotAtOrAbove(yaml,next*9)) { say(player,"&cElimina primero los objetos fuera de las nuevas filas."); return true; }
            yaml.set("menu.rows",next); save(player,id,yaml); show(player,id,-1);
        } else if(slot==47) plugin.openMenu(player,id,false);
        else if(slot==48) say(player,"&aLos cambios ya están guardados.");
        else if(slot==49) player.closeInventory();
        else if(selected>=0 && slot==50) prompt(player,id,selected,"name","Escribe el nombre del objeto. 'cancel' para cancelar.");
        else if(selected>=0 && slot==51) prompt(player,id,selected,"lore","Escribe el lore separando las líneas con |. 'cancel' para cancelar.");
        else if(selected>=0 && slot==52) {
            ItemStack held=player.getInventory().getItemInMainHand();
            if (held.getType().isAir() || !held.getType().isItem()) { say(player,"&cSostén un material válido en la mano principal."); return true; }
            YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file(id)); String path=pathForSlot(yaml,selected);
            if(path!=null) { yaml.set(path+".material",held.getType().name()); save(player,id,yaml); show(player,id,selected); }
        } else if(selected>=0 && slot==53) {
            if(!event.isShiftClick()) { say(player,"&cUsa Shift + clic para eliminar el objeto."); return true; }
            YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file(id)); String path=pathForSlot(yaml,selected);
            if(path!=null) { yaml.set(path,null); save(player,id,yaml); show(player,id,-1); }
        }
        return true;
    }
    private String pathForSlot(YamlConfiguration yaml,int slot) {
        ConfigurationSection items=yaml.getConfigurationSection("items");
        if(items==null) return null;
        for(String key:items.getKeys(false)) if(yaml.getInt("items."+key+".slot",-1)==slot) return "items."+key;
        return null;
    }
    private boolean hasSlot(YamlConfiguration yaml,int slot) { return pathForSlot(yaml,slot)!=null; }
    private boolean hasSlotAtOrAbove(YamlConfiguration yaml,int limit) {
        ConfigurationSection items=yaml.getConfigurationSection("items");
        if(items==null) return false;
        for(String key:items.getKeys(false)) if(yaml.getInt("items."+key+".slot",-1)>=limit) return true;
        return false;
    }
    private void prompt(Player player,String id,int slot,String field,String instruction) {
        pending.put(player.getUniqueId(),new PendingInput(id,slot,field));
        player.closeInventory(); say(player,"&e"+instruction);
    }
    @EventHandler(priority=EventPriority.LOWEST) public void chat(AsyncChatEvent event) {
        UUID uuid=event.getPlayer().getUniqueId();
        // PendingInput is read and removed on the primary thread; chat callback itself may be asynchronous.
        if (!pending.containsKey(uuid)) return;
        event.setCancelled(true);
        String value=PlainTextComponentSerializer.plainText().serialize(event.message());
        Bukkit.getScheduler().runTask(plugin,()-> {
            PendingInput input=pending.remove(uuid);
            if(input==null) return;
            Player player=Bukkit.getPlayer(uuid);
            if(player==null || !player.hasPermission("wzmenus.edit")) return;
            if(value.equalsIgnoreCase("cancel")) { say(player,"&7Edición cancelada."); show(player,input.id(),input.slot()); return; }
            if(value.length()>512) { say(player,"&cTexto demasiado largo (máximo 512 caracteres)."); show(player,input.id(),input.slot()); return; }
            YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file(input.id()));
            String path=input.slot()<0?"menu":pathForSlot(yaml,input.slot());
            if(path==null) { say(player,"&cObjeto no encontrado."); return; }
            if(input.field().equals("lore")) yaml.set(path+".lore",Arrays.asList(value.split("\\|",-1)));
            else yaml.set(path+"."+input.field(),value);
            save(player,input.id(),yaml); show(player,input.id(),input.slot());
        });
    }
    private void save(Player player,String id,YamlConfiguration yaml) {
        try { yaml.save(file(id)); plugin.menus().load(); say(player,"&aCambios guardados correctamente."); }
        catch(IOException ex) { plugin.getLogger().warning("Error al guardar "+id+": "+ex.getMessage()); say(player,"&cNo se pudieron guardar los cambios."); }
    }
}
