package ws.wzstudios.wzmenus;

import org.bukkit.Material;
import java.util.List;
import java.util.Map;

public record MenuDefinition(String id, String title, int rows, String permission, List<String> commands,
                             Material fillerMaterial, String fillerName, List<Integer> fillerSlots,
                             Map<Integer, MenuEntry> items, boolean pagination, int nextSlot, int previousSlot, int refreshTicks) {
    public record MenuEntry(String id, Material material, int amount, String name, List<String> lore,
                            Map<String, List<String>> actions, String permission, String denyMessage,
                            String headDatabaseId, String skullOwner, String viewRegion, String clickRegion,
                            String regionDenyMessage, int page, long cooldownSeconds, String cooldownMessage) { }
}
