package ws.wzstudios.wzmenus;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class EditorHolder implements InventoryHolder {
    private Inventory inventory;
    private final String menuId;
    private final int selectedSlot;
    public EditorHolder(String menuId, int selectedSlot) { this.menuId=menuId; this.selectedSlot=selectedSlot; }
    public String menuId() { return menuId; }
    public int selectedSlot() { return selectedSlot; }
    public void setInventory(Inventory inventory) { this.inventory=inventory; }
    @Override public Inventory getInventory() { return inventory; }
}
