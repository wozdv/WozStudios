package ws.wzstudios.wzmenus;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.*;

public final class WzMenusPlugin extends JavaPlugin implements Listener, TabExecutor {
    private TextFormat text;
    private MenuManager manager;
    private YamlConfiguration messages;
    private ActionEngine actionEngine;
    private Integrations integrations;
    private MenuEditor editor;
    private ClaimCooldowns claimCooldowns;
    private org.bukkit.scheduler.BukkitTask refreshTask;
    public Integrations integrations() { return integrations; }
    private final Map<UUID, Deque<String>> history = new HashMap<>();
    public TextFormat text() { return text; }
    public MenuManager menus() { return manager; }

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResourceIfMissing("messages.yml");
        saveResourceIfMissing("menus/example.yml");
        saveResourceIfMissing("menus/information.yml");
        saveResourceIfMissing("menus/integrations.yml");
        text = new TextFormat();
        manager = new MenuManager(this);
        actionEngine = new ActionEngine(this);
        integrations = new Integrations(this);
        editor = new MenuEditor(this);
        claimCooldowns = new ClaimCooldowns(this);
        reloadAll();
        refreshTask = Bukkit.getScheduler().runTaskTimer(this, this::refreshVisibleMenus, 5L, 5L);
        Objects.requireNonNull(getCommand("wzmenus")).setExecutor(this);
        Objects.requireNonNull(getCommand("wzmenus")).setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("wzMenus v" + getPluginMeta().getVersion() + " | Wz Studios");
    }
    @Override public void onDisable() {
        if (refreshTask != null) refreshTask.cancel();
        history.clear();
        if (editor != null) editor.cancelAll();
        if (claimCooldowns != null) claimCooldowns.save();
    }
    private long refreshTick = 0;
    private void refreshVisibleMenus() {
        refreshTick += 5;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder holder)) continue;
            MenuDefinition menu = manager.get(holder.menu().id());
            if (menu == null || menu.refreshTicks() == 0 || refreshTick % menu.refreshTicks() != 0) continue;
            // Do not replace the open inventory: avoids flickering and cursor disruptions.
            // Only update the contents if the menu remains accessible.
            manager.refresh(player, holder);
        }
    }
    private void saveResourceIfMissing(String path) {
        if (!new File(getDataFolder(), path).exists()) saveResource(path, false);
    }
    private void reloadAll() {
        reloadConfig();
        integrations.reload();
        messages = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
        manager.load();
        history.clear();
        if (editor != null) editor.cancelAll();
    }
    public void message(CommandSender sender, String key, Map<String, String> placeholders) {
        String raw = messages.getString(key, key);
        for (var entry : placeholders.entrySet()) raw = raw.replace("%" + entry.getKey() + "%", entry.getValue());
        sender.sendMessage(text.parse(messages.getString("prefix", "") ).append(text.parse(raw)));
    }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) { message(sender, "usage", Map.of()); return true; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "edit" -> {
                if (!sender.hasPermission("wzmenus.edit")) { message(sender,"no-permission",Map.of()); return true; }
                if (!(sender instanceof Player p)) { message(sender,"player-only",Map.of()); return true; }
                if (args.length < 2) { message(sender,"usage",Map.of()); return true; }
                editor.open(p,args[1]);
            }
            case "create" -> {
                if (!sender.hasPermission("wzmenus.create")) { message(sender,"no-permission",Map.of()); return true; }
                if (args.length < 2) { message(sender,"usage",Map.of()); return true; }
                editor.create(sender,args[1]);
            }
            case "delete" -> {
                if (!sender.hasPermission("wzmenus.delete")) { message(sender,"no-permission",Map.of()); return true; }
                if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) { sender.sendMessage(text.parse("&cUso: /wzmenus delete <id> confirm")); return true; }
                editor.delete(sender,args[1]);
            }
            case "open" -> {
                if (!sender.hasPermission("wzmenus.open")) { message(sender,"no-permission",Map.of()); return true; }
                if (args.length < 2) { message(sender,"usage",Map.of()); return true; }
                Player target;
                if (args.length >= 3) {
                    if (!sender.hasPermission("wzmenus.open.others")) { message(sender,"no-permission",Map.of()); return true; }
                    target = Bukkit.getPlayerExact(args[2]);
                } else if (sender instanceof Player player) target = player;
                else { message(sender,"player-only",Map.of()); return true; }
                if (target == null) { message(sender,"unknown-player",Map.of()); return true; }
                openMenu(target,args[1],false);
            }
            case "list" -> {
                if (!sender.hasPermission("wzmenus.admin")) { message(sender,"no-permission",Map.of()); return true; }
                message(sender,"list",Map.of("menus",String.join(", ",manager.ids())));
            }
            case "reload" -> {
                if (!sender.hasPermission("wzmenus.reload")) { message(sender,"no-permission",Map.of()); return true; }
                reloadAll();
                message(sender,"reloaded",Map.of("count",String.valueOf(manager.ids().size())));
            }
            case "validate" -> {
                if (!sender.hasPermission("wzmenus.validate")) { message(sender,"no-permission",Map.of()); return true; }
                if (manager.problems().isEmpty()) message(sender,"validation-ok",Map.of());
                else message(sender,"validation-failed",Map.of("count",String.valueOf(manager.problems().size())));
            }
            default -> message(sender,"usage",Map.of());
        }
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("open","list","reload","validate","edit","create","delete").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 2 && (args[0].equalsIgnoreCase("open") || args[0].equalsIgnoreCase("edit") || args[0].equalsIgnoreCase("delete"))) return manager.ids().stream().filter(s -> s.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 3 && args[0].equalsIgnoreCase("open") && sender.hasPermission("wzmenus.open.others")) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(s -> s.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))).toList();
        return List.of();
    }
    @EventHandler public void onClick(InventoryClickEvent event) {
        if (editor.handleClick(event)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        MenuDefinition menu = holder.menu();
        int clicked = event.getRawSlot();
        if (menu.pagination() && (clicked == menu.nextSlot() || clicked == menu.previousSlot())) {
            int targetPage = holder.page() + (clicked == menu.nextSlot() ? 1 : -1);
            Bukkit.getScheduler().runTask(this, () -> manager.open(player, menu.id(), targetPage));
            return;
        }
        MenuDefinition.MenuEntry entry = menu.items().get(clicked);
        if (entry != null && entry.page() != holder.page()) return;
        if (entry == null) return;
        if (!entry.clickRegion().isBlank() && !integrations.inRegion(player, entry.clickRegion())) {
            player.sendMessage(text.parse(integrations.placeholders(player, entry.regionDenyMessage())));
            return;
        }
        if (!entry.permission().isBlank() && !player.hasPermission(entry.permission())) {
            if (!entry.denyMessage().isBlank()) player.sendMessage(text.parse(integrations.placeholders(player, entry.denyMessage())));
            else message(player, "no-permission", Map.of());
            return;
        }
        String type;
        if (event.isShiftClick()) type = event.isRightClick() ? "shift-right-click" : "shift-left-click";
        else if (event.getClick() == ClickType.MIDDLE) type = "middle-click";
        else type = event.isRightClick() ? "right-click" : "left-click";
        List<String> actions = entry.actions().getOrDefault(type, List.of());
        if (actions.isEmpty()) return;
        if (entry.cooldownSeconds() > 0) {
            long remaining = claimCooldowns.remaining(player.getUniqueId(), menu.id(), entry.id());
            if (remaining > 0) {
                String template = entry.cooldownMessage().isBlank()
                        ? messages.getString("claim-cooldown", "&cEspera &f%time% &cpara reclamar de nuevo.")
                        : entry.cooldownMessage();
                player.sendMessage(text.parse(messages.getString("prefix", "")).append(text.parse(
                        integrations.placeholders(player, template.replace("%time%", ClaimCooldowns.format(remaining))
                                .replace("%seconds%", Long.toString(remaining))))));
                return;
            }
            // Reserva inmediata para impedir doble clic antes de ejecutar las acciones.
            claimCooldowns.claim(player.getUniqueId(), menu.id(), entry.id(), entry.cooldownSeconds());
        }
        Bukkit.getScheduler().runTask(this, () -> {
            if (player.isOnline()) actionEngine.execute(player, actions, holder.menu().id());
        });
    }
    public boolean openMenu(Player player, String id, boolean remember) {
        String previous = null;
        if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder holder) previous = holder.menu().id();
        if (manager.get(id) == null) return manager.open(player, id);
        if (remember && previous != null && !previous.equalsIgnoreCase(id)) {
            Deque<String> stack = history.computeIfAbsent(player.getUniqueId(), key -> new ArrayDeque<>());
            if (stack.size() >= 20) stack.removeLast();
            stack.push(previous);
        }
        return manager.open(player, id);
    }
    public void back(Player player) {
        Deque<String> stack = history.get(player.getUniqueId());
        if (stack != null && !stack.isEmpty()) openMenu(player, stack.pop(), false);
        else message(player, "no-history", Map.of());
    }
    @EventHandler public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) { history.remove(event.getPlayer().getUniqueId()); editor.quit(event.getPlayer()); }
    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof EditorHolder) { event.setCancelled(true); return; }
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        for (int slot : event.getRawSlots()) if (slot < event.getView().getTopInventory().getSize()) { event.setCancelled(true); return; }
    }
}
