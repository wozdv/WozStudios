package ws.wzstudios.wzmenus;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.io.File;
import java.util.*;
import java.util.logging.Level;

public final class MenuManager {
    private final WzMenusPlugin plugin;
    private final Map<String, MenuDefinition> menus = new LinkedHashMap<>();
    private final List<String> problems = new ArrayList<>();
    public MenuManager(WzMenusPlugin plugin) { this.plugin = plugin; }
    public Set<String> ids() { return Collections.unmodifiableSet(menus.keySet()); }
    public List<String> problems() { return Collections.unmodifiableList(problems); }
    public MenuDefinition get(String id) { return menus.get(id.toLowerCase(Locale.ROOT)); }

    public void load() {
        menus.clear(); problems.clear();
        File folder = new File(plugin.getDataFolder(), "menus");
        if (!folder.exists() && !folder.mkdirs()) problems.add("No se pudo crear la carpeta menus/");
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".yml"));
        if (files == null) { problems.add("No se pudo leer la carpeta menus/"); return; }
        Arrays.sort(files, Comparator.comparing(File::getName));
        for (File file : files) {
            String id = file.getName().substring(0, file.getName().length() - 4).toLowerCase(Locale.ROOT);
            try { menus.put(id, read(id, YamlConfiguration.loadConfiguration(file))); }
            catch (IllegalArgumentException ex) { problems.add(file.getName() + ": " + ex.getMessage()); }
            catch (Exception ex) { problems.add(file.getName() + ": " + ex); plugin.getLogger().log(Level.WARNING, "Error al cargar " + file.getName(), ex); }
        }
        for (String issue : problems) plugin.getLogger().warning("[Validación] " + issue);
        plugin.getLogger().info("Menús cargados: " + menus.size() + ", problemas: " + problems.size());
    }

    private MenuDefinition read(String id, YamlConfiguration cfg) {
        ConfigurationSection root = cfg.getConfigurationSection("menu");
        if (root == null) throw new IllegalArgumentException("Falta la sección menu");
        int rows = root.getInt("rows", 3);
        if (rows < 1 || rows > 6) throw new IllegalArgumentException("menu.rows debe estar entre 1 y 6");
        Map<Integer, MenuDefinition.MenuEntry> entries = new LinkedHashMap<>();
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items != null) for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) throw new IllegalArgumentException("items." + key + " debe ser una sección");
            int slot = item.getInt("slot", -1);
            if (slot < 0 || slot >= rows * 9) throw new IllegalArgumentException("Slot inválido: " + key + " = " + slot);
            if (entries.containsKey(slot)) throw new IllegalArgumentException("Slot duplicado: " + slot);
            Material material = material(item.getString("material", "STONE"), "items." + key);
            int amount = item.getInt("amount", 1);
            if (amount < 1 || amount > material.getMaxStackSize()) throw new IllegalArgumentException("Cantidad inválida en " + key);
            Map<String, List<String>> actions = new HashMap<>();
            ConfigurationSection actionSection = item.getConfigurationSection("actions");
            if (actionSection != null) for (String click : actionSection.getKeys(false)) {
                actions.put(click.toLowerCase(Locale.ROOT), List.copyOf(actionSection.getStringList(click)));
            }
            entries.put(slot, new MenuDefinition.MenuEntry(key, material, amount, item.getString("name", key),
                    List.copyOf(item.getStringList("lore")), Map.copyOf(actions),
                    item.getString("click-permission", ""), item.getString("deny-message", ""),
                    item.getString("head-database.id", ""), item.getString("skull-owner", ""),
                    item.getString("view-requirements.region", ""), item.getString("click-requirements.region", ""),
                    item.getString("region-deny-message", "&cNo puedes usar esto en esta región."), item.getInt("page", 1), cooldownSeconds(item, key),
                    item.getString("cooldown.message", "")));
        }
        boolean paginated = root.getBoolean("pagination.enabled", false);
        int nextSlot = root.getInt("pagination.next-slot", rows * 9 - 1);
        int prevSlot = root.getInt("pagination.previous-slot", rows * 9 - 9);
        int refresh = root.getInt("refresh-ticks", 0);
        if (refresh < 0 || (refresh > 0 && refresh < 5 || refresh % 5 != 0)) throw new IllegalArgumentException("refresh-ticks debe ser 0 o >= 5");
        if (paginated) {
            if (nextSlot < 0 || nextSlot >= rows * 9 || prevSlot < 0 || prevSlot >= rows * 9 || nextSlot == prevSlot)
                throw new IllegalArgumentException("Slots de paginación inválidos");
            if (entries.containsKey(nextSlot) || entries.containsKey(prevSlot))
                throw new IllegalArgumentException("Los slots de navegación están ocupados por items");
        }
        for (var e : entries.values()) if (e.page() < 1 || (!paginated && e.page() != 1))
            throw new IllegalArgumentException("items." + e.id() + ": página inválida");
        Material filler = material(cfg.getString("filler.material", "BLACK_STAINED_GLASS_PANE"), "filler.material");
        List<Integer> fillerSlots = new ArrayList<>();
        for (String part : cfg.getStringList("filler.slots")) {
            String[] range = part.split("-", -1);
            try {
                int start = Integer.parseInt(range[0]);
                int end = range.length == 2 ? Integer.parseInt(range[1]) : start;
                if (range.length > 2 || start < 0 || end < start || end >= rows * 9) throw new NumberFormatException();
                for (int s = start; s <= end; s++) fillerSlots.add(s);
            } catch (NumberFormatException ex) { throw new IllegalArgumentException("Rango filler.slots inválido: " + part); }
        }
        return new MenuDefinition(id, root.getString("title", id), rows, root.getString("permission", ""),
                List.copyOf(root.getStringList("commands")), filler, cfg.getString("filler.name", " "),
                List.copyOf(fillerSlots), Map.copyOf(entries),
                root.getBoolean("pagination.enabled", false), root.getInt("pagination.next-slot", rows * 9 - 1),
                root.getInt("pagination.previous-slot", rows * 9 - 9), root.getInt("refresh-ticks", 0));
    }

    private long cooldownSeconds(ConfigurationSection item, String key) {
        long seconds = item.getLong("cooldown.seconds", 0L);
        if (seconds < 0 || seconds > 315360000L) throw new IllegalArgumentException("Cooldown inválido: " + key);
        return seconds;
    }

    private Material material(String value, String where) {
        Material material = Material.matchMaterial(value == null ? "" : value);
        if (material == null || material.isAir() || !material.isItem()) throw new IllegalArgumentException("Material inválido en " + where + ": " + value);
        return material;
    }

    public boolean open(Player player, String id) { return open(player, id, 1); }

    public boolean open(Player player, String id, int page) {
        MenuDefinition menu = get(id);
        if (menu == null) { plugin.message(player, "menu-not-found", Map.of("menu", id)); return false; }
        if (!menu.permission().isBlank() && !player.hasPermission(menu.permission())) { plugin.message(player, "no-permission", Map.of()); return false; }
        int maxPage = menu.items().values().stream().mapToInt(MenuDefinition.MenuEntry::page).max().orElse(1);
        if (page < 1 || page > maxPage) return false;
        MenuHolder holder = new MenuHolder(menu, page);
        Inventory inventory = Bukkit.createInventory(holder, menu.rows() * 9, plugin.text().parse(plugin.integrations().placeholders(player, menu.title())));
        holder.inventory(inventory);
        for (int slot : menu.fillerSlots()) inventory.setItem(slot, item(player, menu.fillerMaterial(), 1, menu.fillerName(), List.of(), null));
        for (Map.Entry<Integer, MenuDefinition.MenuEntry> e : menu.items().entrySet()) {
            MenuDefinition.MenuEntry entry = e.getValue();
            if (entry.page() != page) continue;
            if (!entry.viewRegion().isBlank() && !plugin.integrations().inRegion(player, entry.viewRegion())) continue;
            inventory.setItem(e.getKey(), item(player, entry.material(), entry.amount(), entry.name(), entry.lore(), entry));
        }
        if (menu.pagination()) {
            if (page > 1) inventory.setItem(menu.previousSlot(), item(player, Material.ARROW, 1, "&ePágina anterior", List.of("&7Página " + (page - 1)), null));
            if (page < maxPage) inventory.setItem(menu.nextSlot(), item(player, Material.ARROW, 1, "&ePágina siguiente", List.of("&7Página " + (page + 1)), null));
        }
        player.openInventory(inventory);
        return true;
    }

    public void refresh(Player player, MenuHolder holder) {
        MenuDefinition menu = get(holder.menu().id());
        if (menu == null || menu.rows() != holder.menu().rows()) return;
        if (!menu.permission().isBlank() && !player.hasPermission(menu.permission())) { player.closeInventory(); return; }
        Inventory inv = holder.getInventory();
        int page = holder.page();
        for (int slot = 0; slot < inv.getSize(); slot++) {
            MenuDefinition.MenuEntry entry = menu.items().get(slot);
            if (entry != null && entry.page() == page) {
                if (!entry.viewRegion().isBlank() && !plugin.integrations().inRegion(player, entry.viewRegion())) {
                    inv.setItem(slot, null);
                } else inv.setItem(slot, item(player, entry.material(), entry.amount(), entry.name(), entry.lore(), entry));
            }
        }
    }

    private ItemStack item(Player player, Material material, int amount, String name, List<String> lore, MenuDefinition.MenuEntry entry) {
        ItemStack stack = entry == null ? null : plugin.integrations().head(plugin.integrations().placeholders(player, entry.headDatabaseId()));
        if (stack == null) stack = new ItemStack(material, amount);
        stack.setAmount(amount);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (entry != null && !entry.skullOwner().isBlank() && meta instanceof org.bukkit.inventory.meta.SkullMeta skull) {
                String owner = plugin.integrations().placeholders(player, entry.skullOwner());
                if (!owner.isBlank()) skull.setOwningPlayer(Bukkit.getOfflinePlayer(owner));
            }
            meta.displayName(plugin.text().parse(plugin.integrations().placeholders(player, name)));
            meta.lore(lore.stream().map(s -> plugin.text().parse(plugin.integrations().placeholders(player, s))).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
