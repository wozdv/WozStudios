package ws.wzstudios.wzmenus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Converts legacy (&, hex) and MiniMessage into consistent Adventure components. */
public final class TextFormat {
    private static final Pattern TOKEN = Pattern.compile(
        "(?i)&#([0-9a-f]{6})|&x(?:&[0-9a-f]){6}|&([0-9a-fk-or])");
    private static final String[] COLORS = {
        "black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple",
        "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple",
        "yellow", "white"
    };
    private final MiniMessage mini = MiniMessage.miniMessage();

    public Component parse(String input) {
        if (input == null || input.isEmpty()) return Component.empty();
        StringBuilder converted = new StringBuilder();
        Matcher matcher = TOKEN.matcher(input);
        int pos = 0;
        while (matcher.find()) {
            converted.append(input, pos, matcher.start());
            String token = matcher.group();
            if (matcher.group(1) != null) {
                converted.append("<reset><#").append(matcher.group(1)).append('>');
            } else if (token.length() == 14 && token.regionMatches(true, 0, "&x", 0, 2)) {
                StringBuilder hex = new StringBuilder();
                for (int i = 3; i < token.length(); i += 2) hex.append(token.charAt(i));
                converted.append("<reset><#").append(hex).append('>');
            } else {
                char code = Character.toLowerCase(token.charAt(1));
                if (code >= '0' && code <= '9') converted.append("<reset><").append(COLORS[code-'0']).append('>');
                else if (code >= 'a' && code <= 'f') converted.append("<reset><").append(COLORS[10+code-'a']).append('>');
                else switch (code) {
                    case 'k' -> converted.append("<obfuscated>");
                    case 'l' -> converted.append("<bold>");
                    case 'm' -> converted.append("<strikethrough>");
                    case 'n' -> converted.append("<underlined>");
                    case 'o' -> converted.append("<italic>");
                    case 'r' -> converted.append("<reset>");
                    default -> converted.append(token);
                }
            }
            pos = matcher.end();
        }
        converted.append(input, pos, input.length());
        // In Minecraft item metadata, text is italic by default unless explicitly disabled.
        // This also preserves intentionally requested <italic> and &o spans.
        return Component.empty().decoration(TextDecoration.ITALIC, false)
            .append(mini.deserialize(converted.toString()));
    }
}
