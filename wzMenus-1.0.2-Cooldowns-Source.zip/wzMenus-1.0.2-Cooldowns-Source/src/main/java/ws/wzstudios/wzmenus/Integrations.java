package ws.wzstudios.wzmenus;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Level;

/** Optional integrations loaded only if their plugin is installed and enabled. */
public final class Integrations {
    private final WzMenusPlugin plugin;
    private boolean papi, worldGuard, heads;
    private Object headApi;
    public Integrations(WzMenusPlugin plugin) { this.plugin = plugin; }
    public void reload() {
        papi = enabled("placeholderapi", "PlaceholderAPI");
        worldGuard = enabled("worldguard", "WorldGuard");
        heads = enabled("headdatabase", "HeadDatabase");
        headApi = null;
        if (heads) try {
            Class<?> type = Class.forName("me.arcaniax.hdb.api.HeadDatabaseAPI");
            headApi = type.getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException | LinkageError ex) {
            heads = false;
            plugin.getLogger().warning("HeadDatabase API no disponible: " + ex.getMessage());
        }
        plugin.getLogger().info("Integraciones: PlaceholderAPI=" + papi + ", WorldGuard=" + worldGuard + ", HeadDatabase=" + heads);
    }
    private boolean enabled(String configKey, String name) {
        return plugin.getConfig().getBoolean("integrations." + configKey + ".enabled", true)
            && Bukkit.getPluginManager().isPluginEnabled(name);
    }
    public String placeholders(Player player, String input) {
        String s = input == null ? "" : input.replace("%player_name%", player.getName()).replace("%player%", player.getName());
        if (!papi) return s;
        try {
            Class<?> type = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            Object result = type.getMethod("setPlaceholders", Player.class, String.class).invoke(null, player, s);
            return result instanceof String str ? str : s;
        } catch (ReflectiveOperationException | LinkageError ex) {
            plugin.getLogger().log(Level.WARNING, "Error de PlaceholderAPI", ex);
            return s;
        }
    }
    public ItemStack head(String id) {
        if (!heads || headApi == null || id == null || id.isBlank()) return null;
        try {
            Object item = headApi.getClass().getMethod("getItemHead", String.class).invoke(headApi, id);
            return item instanceof ItemStack stack ? stack.clone() : null;
        } catch (ReflectiveOperationException | LinkageError ex) {
            plugin.getLogger().warning("HeadDatabase ID " + id + " no disponible: " + ex.getMessage());
            return null;
        }
    }
    public boolean inRegion(Player player, String region) {
        if (!worldGuard || region == null || region.isBlank()) return false;
        try {
            Class<?> adapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object world = adapter.getMethod("adapt", org.bukkit.World.class).invoke(null, player.getWorld());
            Object location = adapter.getMethod("adapt", org.bukkit.Location.class).invoke(null, player.getLocation());
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Object wg = wgClass.getMethod("getInstance").invoke(null);
            Object platform = wgClass.getMethod("getPlatform").invoke(wg);
            Object container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
            Class<?> weWorld = Class.forName("com.sk89q.worldedit.world.World");
            Object manager = container.getClass().getMethod("get", weWorld).invoke(container, world);
            if (manager == null) return false;
            Class<?> vec = Class.forName("com.sk89q.worldedit.math.BlockVector3");
            Object pos = location.getClass().getMethod("toBlockPoint").invoke(location);
            Object applicable = manager.getClass().getMethod("getApplicableRegions", vec).invoke(manager, pos);
            if (applicable instanceof Iterable<?> regions) {
                for (Object item : regions) {
                    String id = String.valueOf(item.getClass().getMethod("getId").invoke(item));
                    if (id.equalsIgnoreCase(region)) return true;
                }
            }
        } catch (ReflectiveOperationException | LinkageError ex) {
            plugin.getLogger().warning("WorldGuard region check: " + ex.getMessage());
        }
        return false;
    }
}
